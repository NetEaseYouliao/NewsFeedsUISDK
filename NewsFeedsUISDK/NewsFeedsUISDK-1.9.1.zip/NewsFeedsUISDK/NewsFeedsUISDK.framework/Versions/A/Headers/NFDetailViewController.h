//
//  NFDetailViewController.h
//  NewsFeedsUISDK
//
//  Created by shoulei ma on 2017/10/12.
//  Copyright © 2017年 NetEase. All rights reserved.
//

#import <UIKit/UIKit.h>

@class NFNewsInfo;

@protocol NFNewsMarkReadDelegate <NSObject>

- (void)markRead;

@end

@interface NFDetailViewController : UIViewController

@property (nonatomic, weak)   id<NFNewsMarkReadDelegate> delegate;

@property (nonatomic, copy)   NSString *clickImageURL;

@property (nonatomic, assign) CGRect originFrame;

- (instancetype)initWithNews:(NFNewsInfo *)news config:(NSDictionary *)configuration;

- (void)originFrameWithIndex:(NSInteger)imageIndex block:(void (^)(CGRect frame))block;



@end
