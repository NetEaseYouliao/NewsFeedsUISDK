//
//  NFFuncOption.h
//  NewsFeedsUISDK
//
//  Created by neal on 2017/12/4.
//  Copyright © 2017年 NetEase. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NFFuncOption : NSObject

+ (instancetype)defaultOption;

@end
